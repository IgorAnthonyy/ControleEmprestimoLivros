namespace EmprestimosLivros.Models
{
    public class LivroModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Autor { get; set; }
        public string Editora { get; set; }     
    }
}